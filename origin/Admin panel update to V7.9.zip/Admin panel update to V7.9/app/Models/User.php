<?php

namespace App\Models;


class User extends \App\User
{
    //do not add or remove anything
    //use main App\Users class instead
}
