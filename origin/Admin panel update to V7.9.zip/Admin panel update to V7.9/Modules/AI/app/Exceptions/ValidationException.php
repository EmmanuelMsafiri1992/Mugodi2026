<?php

namespace Modules\AI\app\Exceptions;

class ValidationException extends ApiException
{

}
