<?php

namespace Modules\AI\app\Exceptions;

class UsageLimitException extends ApiException
{

}
