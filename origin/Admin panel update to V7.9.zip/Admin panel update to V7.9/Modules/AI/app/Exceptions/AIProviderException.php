<?php

namespace Modules\AI\app\Exceptions;

class AIProviderException extends ApiException
{

}
