<?php

namespace Modules\AI\app\Exceptions;

class ImageValidationException extends ApiException
{

}
