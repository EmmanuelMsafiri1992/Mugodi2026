<?php

namespace Modules\AI\app\PromptTemplates;

class CategoryTemplate
{

}
