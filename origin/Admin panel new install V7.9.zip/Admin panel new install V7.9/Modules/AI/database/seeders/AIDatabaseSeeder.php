<?php

namespace Modules\AI\database\seeders;

use Illuminate\Database\Seeder;

class AIDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
