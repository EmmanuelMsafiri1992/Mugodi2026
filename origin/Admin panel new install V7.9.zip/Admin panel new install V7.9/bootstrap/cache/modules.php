<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AI\\app\\Providers\\AIServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AI\\app\\Providers\\AIServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);